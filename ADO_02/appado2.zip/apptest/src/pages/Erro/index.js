import { Link } from "react-router-dom";

function Erro(){



    return(
        <div>
            <h1 align='center'>Erro ao entrar</h1>
        </div>
    )
}

export default Erro;